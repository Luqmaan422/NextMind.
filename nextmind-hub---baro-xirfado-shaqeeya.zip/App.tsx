
import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { SkillCard } from './components/SkillCard';
import { Dashboard } from './components/Dashboard';
import { SKILLS, HOW_IT_WORKS } from './constants';
import { User } from './types';
import { 
  ArrowRight, 
  CheckCircle2, 
  AlertCircle, 
  Instagram, 
  Youtube, 
  Mail, 
  Phone, 
  Send,
  Sparkles,
  Bot
} from 'lucide-react';

const App: React.FC = () => {
  const [view, setView] = useState<'landing' | 'dashboard' | 'register'>('landing');
  const [user, setUser] = useState<User | null>(null);

  // Form states
  const [regData, setRegData] = useState({ name: '', email: '', phone: '', interest: 'nocode' });

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    const newUser: User = { ...regData, isRegistered: true };
    setUser(newUser);
    setView('dashboard');
    window.scrollTo(0, 0);
  };

  const LandingView = () => (
    <div className="w-full">
      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <div className="absolute inset-0 bg-gradient-to-b from-[#050614]/20 via-[#050614]/80 to-[#050614] z-10" />
          <img 
            src="https://images.unsplash.com/photo-1635070041078-e363dbe005cb?auto=format&fit=crop&q=80&w=2000" 
            alt="Hero Background" 
            className="w-full h-full object-cover"
          />
        </div>
        
        <div className="relative z-20 text-center px-4 max-w-4xl mx-auto">
          <div className="inline-flex items-center px-4 py-2 bg-purple-500/10 border border-purple-500/30 rounded-full text-purple-400 text-sm font-bold mb-8 animate-bounce">
            <Sparkles className="w-4 h-4 mr-2" /> 100% Practical Learning
          </div>
          <h1 className="text-5xl md:text-8xl font-black mb-6 font-poppins tracking-tighter leading-tight">
            Baro Xirfado <span className="text-purple-500 neon-glow">Shaqeeya</span> – Ma Aha Courses Kaliya
          </h1>
          <p className="text-xl md:text-2xl text-gray-300 mb-10 max-w-2xl mx-auto leading-relaxed">
            NextMind Hub: Baro, Dhis, Caddee, Guuleyso. Noqo mid ka mid ah dhalinyarada mustaqbalka.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <button 
              onClick={() => setView('register')}
              className="w-full sm:w-auto px-10 py-5 bg-purple-600 hover:bg-purple-700 text-white font-bold rounded-2xl transition-all neon-border text-lg"
            >
              Bilow Xirfad Maanta <ArrowRight className="inline ml-2" />
            </button>
            <button 
              onClick={() => document.getElementById('problem')?.scrollIntoView({ behavior: 'smooth' })}
              className="w-full sm:w-auto px-10 py-5 bg-white/5 hover:bg-white/10 text-white font-bold rounded-2xl transition border border-white/10 text-lg"
            >
              Sidee u shaqeeyaa?
            </button>
          </div>
        </div>
      </section>

      {/* Problem + Solution Section */}
      <section id="problem" className="py-24 px-4 max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="glass-card p-10 rounded-3xl border-red-500/20">
            <AlertCircle className="w-16 h-16 text-red-500 mb-6" />
            <h2 className="text-3xl font-bold mb-4 font-poppins">Dhibaatada Jira</h2>
            <p className="text-gray-400 text-lg">
              Dhalinyaradu waxay daawadaan casharro saacado badan ah laakiin marka ay dhamaato ma helaan xirfad dhab ah oo ay ku shaqayn karaan.
            </p>
          </div>
          <div className="glass-card p-10 rounded-3xl border-green-500/20 relative overflow-hidden group">
            <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:scale-110 transition-transform">
              <CheckCircle2 className="w-32 h-32 text-green-500" />
            </div>
            <CheckCircle2 className="w-16 h-16 text-green-500 mb-6" />
            <h2 className="text-3xl font-bold mb-4 font-poppins">Xalka NextMind</h2>
            <p className="text-gray-400 text-lg">
              Micro-Skills System – Casharro gaagaaban, proof-based, iyo natiijo muuqata. Ma baranaysid ilaa aad wax dhistid.
            </p>
          </div>
        </div>
      </section>

      {/* Skills Section */}
      <section id="skills" className="py-24 px-4 max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-6xl font-black mb-4 neon-glow">Xirfadaha Diyaar ah</h2>
          <p className="text-gray-400 max-w-xl mx-auto">Dooro mid ka mid ah xirfadahan casriga ah si aad u bilowdo safarkaaga.</p>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {SKILLS.map(skill => (
            <SkillCard key={skill.id} skill={skill} onClick={() => setView('register')} />
          ))}
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-24 bg-white/5">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-4xl font-black mb-16 text-center neon-glow">Sidee u shaqeeyaa?</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12 relative">
            <div className="hidden md:block absolute top-1/4 left-1/4 right-1/4 h-0.5 border-t-2 border-dashed border-purple-500/30" />
            {HOW_IT_WORKS.map((step, idx) => (
              <div key={idx} className="relative z-10 flex flex-col items-center text-center">
                <div className="w-20 h-20 bg-[#050614] border-2 border-purple-500 rounded-2xl flex items-center justify-center mb-6 neon-border shadow-purple-500/20 shadow-xl">
                  {step.icon}
                </div>
                <h3 className="text-2xl font-bold mb-4 font-poppins">{step.title}</h3>
                <p className="text-gray-400">{step.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* AI Mentor Section */}
      <section className="py-24 px-4">
        <div className="max-w-5xl mx-auto glass-card p-12 rounded-[3rem] border-purple-500/40 text-center relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-purple-500 to-transparent" />
          <Bot className="w-20 h-20 text-purple-400 mx-auto mb-8 animate-pulse" />
          <h2 className="text-4xl font-black mb-6">Future Vision: AI Mentor</h2>
          <p className="text-xl text-gray-300 mb-10 max-w-2xl mx-auto">
            NextMind Hub waxay noqon doontaa AI Mentor-kaaga gaarka ah ee kugu hagaya xirfad kasta, ka saxaya khaladaadka, kugu dhiirigalinaya guusha.
          </p>
          <button 
            onClick={() => setView('register')}
            className="bg-white text-[#050614] px-10 py-4 rounded-2xl font-black text-lg hover:bg-purple-100 transition shadow-xl"
          >
            Join the Waitlist
          </button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-black/40 border-t border-white/5 py-20 px-4">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-12">
          <div className="md:col-span-2">
            <div className="flex items-center mb-6">
              <BrainCircuit className="w-8 h-8 text-purple-500 mr-2" />
              <span className="text-2xl font-black tracking-tighter">NEXTMIND</span>
            </div>
            <p className="text-gray-400 max-w-md">
              Waxaan dhisaynaa jiilkii ugu horeeyay ee Soomaaliyeed ee xirfado dhab ah oo casri ah leh.
            </p>
          </div>
          <div>
            <h4 className="font-bold mb-6 text-purple-400">Quick Links</h4>
            <ul className="space-y-4 text-gray-400">
              <li><button onClick={() => window.scrollTo(0,0)} className="hover:text-purple-300 transition">About Us</button></li>
              <li><button onClick={() => document.getElementById('skills')?.scrollIntoView()} className="hover:text-purple-300 transition">Our Skills</button></li>
              <li><button className="hover:text-purple-300 transition">Privacy Policy</button></li>
            </ul>
          </div>
          <div>
            <h4 className="font-bold mb-6 text-purple-400">Contact</h4>
            <ul className="space-y-4 text-gray-400">
              <li className="flex items-center"><Mail className="w-5 h-5 mr-2 text-purple-500" /> info@nextmindhub.com</li>
              <li className="flex items-center"><Phone className="w-5 h-5 mr-2 text-purple-500" /> +2520672187444</li>
              <li className="flex space-x-4 mt-6">
                <a href="#" className="p-2 bg-white/5 rounded-lg hover:bg-purple-500/20 transition"><Instagram /></a>
                <a href="#" className="p-2 bg-white/5 rounded-lg hover:bg-purple-500/20 transition"><Youtube /></a>
                <a href="#" className="p-2 bg-white/5 rounded-lg hover:bg-purple-500/20 transition"><Send /></a>
              </li>
            </ul>
          </div>
        </div>
        <div className="max-w-7xl mx-auto mt-20 pt-8 border-t border-white/5 text-center text-gray-500 text-sm">
          &copy; {new Date().getFullYear()} NextMind Hub. All rights reserved.
        </div>
      </footer>
    </div>
  );

  const RegisterView = () => (
    <div className="min-h-screen pt-32 pb-20 px-4 flex items-center justify-center">
      <div className="max-w-md w-full glass-card p-10 rounded-3xl border-purple-500/30">
        <h2 className="text-3xl font-black mb-2 text-center neon-glow">Ku Biir Hadda</h2>
        <p className="text-gray-400 text-center mb-10">Bilow safarkaaga xirfadeed maanta.</p>
        
        <form onSubmit={handleRegister} className="space-y-6">
          <div>
            <label className="block text-sm text-gray-400 mb-2">Magacaaga Afka Buuxa</label>
            <input 
              required
              type="text" 
              className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-4 focus:outline-none focus:border-purple-500 transition"
              value={regData.name}
              onChange={(e) => setRegData({...regData, name: e.target.value})}
              placeholder="Geli magacaaga..."
            />
          </div>
          <div>
            <label className="block text-sm text-gray-400 mb-2">Email</label>
            <input 
              required
              type="email" 
              className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-4 focus:outline-none focus:border-purple-500 transition"
              value={regData.email}
              onChange={(e) => setRegData({...regData, email: e.target.value})}
              placeholder="emailkaaga@example.com"
            />
          </div>
          <div>
            <label className="block text-sm text-gray-400 mb-2">Numberka Phone-ka</label>
            <input 
              required
              type="tel" 
              className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-4 focus:outline-none focus:border-purple-500 transition"
              value={regData.phone}
              onChange={(e) => setRegData({...regData, phone: e.target.value})}
              placeholder="+252..."
            />
          </div>
          <div>
            <label className="block text-sm text-gray-400 mb-2">Xirfadda aad Xiisaynayso</label>
            <select 
              className="w-full bg-[#0a0b1e] border border-white/10 rounded-xl px-4 py-4 focus:outline-none focus:border-purple-500"
              value={regData.interest}
              onChange={(e) => setRegData({...regData, interest: e.target.value})}
            >
              {SKILLS.map(s => <option key={s.id} value={s.id}>{s.title}</option>)}
            </select>
          </div>
          <button 
            type="submit" 
            className="w-full bg-purple-600 hover:bg-purple-700 text-white py-5 rounded-2xl font-black text-lg transition-all neon-border"
          >
            Bilow Hadda
          </button>
        </form>
        <p className="mt-6 text-center text-sm text-gray-500">
          Adigoo is-diiwaangelinaya, waxaad aqbashay shuruudaha NextMind.
        </p>
      </div>
    </div>
  );

  return (
    <div className="bg-[#050614] min-h-screen">
      <Navbar 
        onNavigate={(v) => { setView(v); window.scrollTo(0, 0); }} 
        currentView={view} 
        user={user} 
      />
      
      <main>
        {view === 'landing' && <LandingView />}
        {view === 'register' && <RegisterView />}
        {view === 'dashboard' && user && <Dashboard user={user} />}
      </main>
    </div>
  );
};

export default App;

import { BrainCircuit } from 'lucide-react';
