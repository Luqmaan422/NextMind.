
export interface User {
  name: string;
  email: string;
  phone: string;
  interest: string;
  isRegistered: boolean;
}

export interface Skill {
  id: string;
  title: string;
  description: string;
  image: string;
  cta: string;
}

export interface ProofSubmission {
  id: string;
  skillId: string;
  skillName: string;
  link: string;
  status: 'pending' | 'approved' | 'rejected';
  date: string;
}

export interface NavigationProps {
  onNavigate: (view: 'landing' | 'dashboard' | 'register') => void;
  currentView: string;
  user: User | null;
}
