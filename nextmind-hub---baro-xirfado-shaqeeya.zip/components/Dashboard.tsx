
import React, { useState } from 'react';
import { User, ProofSubmission } from '../types';
import { SKILLS } from '../constants';
import { CheckCircle, Clock, Send, Plus, LayoutDashboard, Award } from 'lucide-react';

interface DashboardProps {
  user: User;
}

export const Dashboard: React.FC<DashboardProps> = ({ user }) => {
  const [submissions, setSubmissions] = useState<ProofSubmission[]>([
    {
      id: '1',
      skillId: 'nocode',
      skillName: 'No-Code Websites',
      link: 'https://mywebsite.framer.ai',
      status: 'approved',
      date: '2023-12-01'
    }
  ]);

  const [showForm, setShowForm] = useState(false);
  const [newLink, setNewLink] = useState('');
  const [selectedSkill, setSelectedSkill] = useState(SKILLS[0].id);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const skill = SKILLS.find(s => s.id === selectedSkill);
    const newSub: ProofSubmission = {
      id: Math.random().toString(36).substr(2, 9),
      skillId: selectedSkill,
      skillName: skill?.title || '',
      link: newLink,
      status: 'pending',
      date: new Date().toISOString().split('T')[0]
    };
    setSubmissions([newSub, ...submissions]);
    setNewLink('');
    setShowForm(false);
  };

  return (
    <div className="pt-32 pb-20 px-4 max-w-6xl mx-auto">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-10 gap-4">
        <div>
          <h1 className="text-4xl font-black neon-glow mb-2">Ku soo dhawaaw, {user.name}!</h1>
          <p className="text-gray-400">Hubkaaga micro-skills iyo horumarkaaga.</p>
        </div>
        <button 
          onClick={() => setShowForm(!showForm)}
          className="flex items-center bg-purple-600 hover:bg-purple-700 text-white px-6 py-3 rounded-xl font-bold transition neon-border"
        >
          <Plus className="mr-2 w-5 h-5" /> Gudbi Proof Cusub
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {/* Stats Column */}
        <div className="md:col-span-1 space-y-6">
          <div className="glass-card p-6 rounded-2xl">
            <div className="flex items-center mb-4">
              <LayoutDashboard className="w-5 h-5 text-purple-400 mr-2" />
              <h2 className="font-bold text-lg">Xogta Guud</h2>
            </div>
            <div className="space-y-4">
              <div className="flex justify-between items-center p-3 bg-white/5 rounded-lg">
                <span className="text-gray-400">Dhammaystiray</span>
                <span className="font-bold text-green-400">1 Xirfad</span>
              </div>
              <div className="flex justify-between items-center p-3 bg-white/5 rounded-lg">
                <span className="text-gray-400">Wali Socda</span>
                <span className="font-bold text-yellow-400">2 Xirfad</span>
              </div>
              <div className="flex justify-between items-center p-3 bg-white/5 rounded-lg">
                <span className="text-gray-400">Bhibiladda (Points)</span>
                <span className="font-bold text-purple-400">450 XP</span>
              </div>
            </div>
          </div>

          <div className="glass-card p-6 rounded-2xl bg-gradient-to-br from-purple-900/20 to-transparent border-purple-500/20">
            <div className="flex items-center mb-4">
              <Award className="w-5 h-5 text-yellow-400 mr-2" />
              <h2 className="font-bold text-lg">NextMind Badge</h2>
            </div>
            <div className="text-center py-6">
              <div className="w-24 h-24 mx-auto bg-purple-600/30 rounded-full flex items-center justify-center border-2 border-purple-500/50 mb-4 neon-border">
                <BrainCircuit className="w-12 h-12 text-purple-400" />
              </div>
              <p className="text-sm text-gray-400">Micro-Skill Pioneer</p>
            </div>
          </div>
        </div>

        {/* Main Content Column */}
        <div className="md:col-span-2 space-y-6">
          {showForm && (
            <form onSubmit={handleSubmit} className="glass-card p-8 rounded-2xl border-purple-500/50 animate-in fade-in slide-in-from-top-4 duration-300">
              <h3 className="text-xl font-bold mb-6">Soo Gudbi Cadaynta Mashruucaaga</h3>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm text-gray-400 mb-2">Dooro Xirfadda</label>
                  <select 
                    value={selectedSkill}
                    onChange={(e) => setSelectedSkill(e.target.value)}
                    className="w-full bg-[#0a0b1e] border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-purple-500"
                  >
                    {SKILLS.map(s => <option key={s.id} value={s.id}>{s.title}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-sm text-gray-400 mb-2">Link-ga Mashruuca (e.g. Website, Video link, Google Drive)</label>
                  <input 
                    type="url" 
                    required
                    value={newLink}
                    onChange={(e) => setNewLink(e.target.value)}
                    placeholder="https://..."
                    className="w-full bg-[#0a0b1e] border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-purple-500"
                  />
                </div>
                <button type="submit" className="w-full bg-purple-600 py-4 rounded-xl font-bold hover:bg-purple-700 transition">
                  Gudbi Mashruuca
                </button>
              </div>
            </form>
          )}

          <div className="glass-card p-6 rounded-2xl">
            <h2 className="font-bold text-xl mb-6">Cadaymahaagii Hore (Submissions)</h2>
            <div className="space-y-4">
              {submissions.map((sub) => (
                <div key={sub.id} className="flex items-center justify-between p-4 bg-white/5 rounded-xl border border-white/5">
                  <div className="flex items-center space-x-4">
                    <div className={`p-3 rounded-lg ${sub.status === 'approved' ? 'bg-green-500/20 text-green-400' : 'bg-yellow-500/20 text-yellow-400'}`}>
                      {sub.status === 'approved' ? <CheckCircle className="w-6 h-6" /> : <Clock className="w-6 h-6" />}
                    </div>
                    <div>
                      <h4 className="font-bold">{sub.skillName}</h4>
                      <p className="text-sm text-gray-500">{sub.date}</p>
                    </div>
                  </div>
                  <a 
                    href={sub.link} 
                    target="_blank" 
                    rel="noreferrer" 
                    className="text-purple-400 hover:text-purple-300 text-sm font-medium underline"
                  >
                    View Project
                  </a>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

import { BrainCircuit } from 'lucide-react';
