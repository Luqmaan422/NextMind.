
import React from 'react';
import { Skill } from '../types';
import { ArrowRight } from 'lucide-react';

interface SkillCardProps {
  skill: Skill;
  onClick: () => void;
}

export const SkillCard: React.FC<SkillCardProps> = ({ skill, onClick }) => {
  return (
    <div 
      className="group relative overflow-hidden rounded-2xl aspect-[4/5] cursor-pointer neon-border transition-all duration-500"
      onClick={onClick}
    >
      <img 
        src={skill.image} 
        alt={skill.title} 
        className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-[#050614] via-[#050614]/40 to-transparent" />
      
      <div className="absolute bottom-0 left-0 right-0 p-6 translate-y-4 group-hover:translate-y-0 transition-transform duration-500">
        <h3 className="text-2xl font-bold text-white mb-2 font-poppins">{skill.title}</h3>
        <p className="text-gray-300 text-sm mb-4 opacity-0 group-hover:opacity-100 transition-opacity duration-500 line-clamp-2">
          {skill.description}
        </p>
        <button className="flex items-center text-purple-400 font-bold text-sm group-hover:text-purple-300">
          {skill.cta} <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
        </button>
      </div>
      
      <div className="absolute inset-0 border-2 border-transparent group-hover:border-purple-500/30 rounded-2xl transition-all pointer-events-none" />
    </div>
  );
};
