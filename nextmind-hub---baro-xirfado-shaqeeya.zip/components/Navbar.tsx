
import React from 'react';
import { NavigationProps } from '../types';
import { Menu, X, BrainCircuit } from 'lucide-react';

export const Navbar: React.FC<NavigationProps> = ({ onNavigate, currentView, user }) => {
  const [isOpen, setIsOpen] = React.useState(false);

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-[#050614]/80 backdrop-blur-md border-b border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          <div className="flex items-center cursor-pointer" onClick={() => onNavigate('landing')}>
            <BrainCircuit className="w-10 h-10 text-purple-500 mr-2" />
            <span className="text-2xl font-black font-poppins tracking-tighter bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-white">
              NEXTMIND HUB
            </span>
          </div>

          {/* Desktop Links */}
          <div className="hidden md:block">
            <div className="ml-10 flex items-baseline space-x-8">
              <button onClick={() => onNavigate('landing')} className="text-gray-300 hover:text-purple-400 px-3 py-2 text-sm font-medium transition">Home</button>
              <button onClick={() => {
                const el = document.getElementById('skills');
                if (el) el.scrollIntoView({ behavior: 'smooth' });
              }} className="text-gray-300 hover:text-purple-400 px-3 py-2 text-sm font-medium transition">Skills</button>
              
              {user?.isRegistered ? (
                <button 
                  onClick={() => onNavigate('dashboard')}
                  className="bg-purple-600 hover:bg-purple-700 text-white px-5 py-2 rounded-full text-sm font-bold neon-border transition animate-pulse-purple"
                >
                  Dashboard
                </button>
              ) : (
                <button 
                  onClick={() => onNavigate('register')}
                  className="bg-purple-600 hover:bg-purple-700 text-white px-5 py-2 rounded-full text-sm font-bold neon-border transition"
                >
                  Ku Biir Hadda
                </button>
              )}
            </div>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <button onClick={() => setIsOpen(!isOpen)} className="text-gray-400 hover:text-white transition">
              {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {isOpen && (
        <div className="md:hidden bg-[#050614] border-b border-white/10 py-4 px-6 space-y-4">
          <button onClick={() => { onNavigate('landing'); setIsOpen(false); }} className="block text-gray-300 w-full text-left py-2">Home</button>
          <button onClick={() => { setIsOpen(false); document.getElementById('skills')?.scrollIntoView({ behavior: 'smooth' }); }} className="block text-gray-300 w-full text-left py-2">Skills</button>
          {user?.isRegistered ? (
            <button onClick={() => { onNavigate('dashboard'); setIsOpen(false); }} className="w-full bg-purple-600 text-white py-3 rounded-xl font-bold">Dashboard</button>
          ) : (
            <button onClick={() => { onNavigate('register'); setIsOpen(false); }} className="w-full bg-purple-600 text-white py-3 rounded-xl font-bold">Ku Biir Hadda</button>
          )}
        </div>
      )}
    </nav>
  );
};
