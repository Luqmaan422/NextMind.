
import React from 'react';
import { Layout, Cpu, Video, Briefcase, AlertTriangle, CheckCircle } from 'lucide-react';
import { Skill } from './types';

export const SKILLS: Skill[] = [
  {
    id: 'nocode',
    title: 'No-Code Websites',
    description: 'Baro dhisida websaydhyada adigoon code garanaynin. Ka dhig ganacsigaaga mid online ah.',
    image: 'https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?auto=format&fit=crop&q=80&w=800',
    cta: 'Baro Hadda'
  },
  {
    id: 'ai-tools',
    title: 'AI Tools Mastery',
    description: 'Ka faa’iidayso AI si aad xirfadahaaga u kordhiso. Baro Prompt Engineering iyo Automation.',
    image: 'https://images.unsplash.com/photo-1677442136019-21780ecad995?auto=format&fit=crop&q=80&w=800',
    cta: 'Baro Hadda'
  },
  {
    id: 'video-editing',
    title: 'Video Editing',
    description: 'Baro tafatirka muuqaalada ee casriga ah. Noqo mid ka mid ah kuwa ugu fiican suuqa.',
    image: 'https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?auto=format&fit=crop&q=80&w=800',
    cta: 'Baro Hadda'
  },
  {
    id: 'branding',
    title: 'Online Business',
    description: 'Dhiso ganacsi online iyo sumad shakhsi. Baro sida loo helo macaamiil caalami ah.',
    image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&q=80&w=800',
    cta: 'Baro Hadda'
  }
];

export const HOW_IT_WORKS = [
  {
    title: 'Dooro Skill',
    desc: 'Ka dooro liiska xirfadaha midka aad xiisaynayso.',
    icon: <Layout className="w-8 h-8 text-purple-400" />
  },
  {
    title: 'Baro Cashar Gaaban',
    desc: 'Daawo casharro kooban oo waxqabad ku dhisan.',
    icon: <Cpu className="w-8 h-8 text-purple-400" />
  },
  {
    title: 'Soo Gudbi Proof',
    desc: 'Dhis mashruuc yar, ka dibna soo gudbi cadayntaada.',
    icon: <CheckCircle className="w-8 h-8 text-purple-400" />
  }
];

export const COLORS = {
  bg: '#050614',
  primary: '#a855f7',
  secondary: '#7c3aed',
  accent: '#d8b4fe'
};
